package com.example.fxyjsryrj

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
