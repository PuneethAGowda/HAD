import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';
void main() {
  runApp(MaterialApp(
    home: Scaffold(
      appBar: AppBar(
        title: Text("Scaffold Safe Area usage"),
      ),
      body: Container(
        child: SafeArea(
          child: Center(
            child: Text(
              'This is using Scaffold Safe Area',
              style: TextStyle(
                fontSize: 35.0,
                fontWeight: FontWeight.bold,
              ),),),),),),));}