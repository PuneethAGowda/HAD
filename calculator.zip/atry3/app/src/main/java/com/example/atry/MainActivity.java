package com.example.atry;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button one, two, three, four, five, six, seven, eight, nine, zero;
    Button clear, plus, minus, multiply, divide, equal;
    EditText res;
    String operatorPressed = " ";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        res = findViewById(R.id.res);
        one = findViewById(R.id.one);
        two = findViewById(R.id.two);
        three = findViewById(R.id.three);
        four = findViewById(R.id.four);
        five = findViewById(R.id.five);
        six = findViewById(R.id.six);
        seven = findViewById(R.id.seven);
        eight = findViewById(R.id.eight);
        nine = findViewById(R.id.nine);
        zero = findViewById(R.id.zero);
        clear = findViewById(R.id.clear);
        plus = findViewById(R.id.plus);
        minus = findViewById(R.id.minus);
        divide = findViewById(R.id.divide);
        multiply = findViewById(R.id.multiply);
        equal = findViewById(R.id.equal);

        one.setOnClickListener(this);
        two.setOnClickListener(this);
        three.setOnClickListener(this);
        four.setOnClickListener(this);
        five.setOnClickListener(this);
        six.setOnClickListener(this);
        seven.setOnClickListener(this);
        eight.setOnClickListener(this);
        nine.setOnClickListener(this);
        zero.setOnClickListener(this);
        clear.setOnClickListener(this);
        plus.setOnClickListener(this);
        minus.setOnClickListener(this);
        divide.setOnClickListener(this);
        multiply.setOnClickListener(this);
        equal.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {

        double finalresult = 0.0;

        switch(view.getId())
        {
            case R.id.one: res.append("1");
                break;

            case R.id.two: res.append("2");
                break;

            case R.id.three: res.append("3");
                break;

            case R.id.four: res.append("4");
                break;

            case R.id.five: res.append("5");
                break;

            case R.id.six: res.append("6");
                break;
            case R.id.seven: res.append("7");
                break;
            case R.id.eight: res.append("8");
                break;
            case R.id.nine: res.append("9");
                break;

            case R.id.plus: res.append("+");
                operatorPressed = "+";
                break;

            case R.id.minus: res.append("-");
                operatorPressed = "-";
                break;
            case R.id.divide: res.append("/");
                operatorPressed = "/";
                break;
            case R.id.multiply: res.append("*");
                operatorPressed = "*";
                break;
            case R.id.clear: res.setText(" ");
                break;

            case R.id.equal: finalresult = evaluateExpression(res.getText().toString(), operatorPressed);
                res.setText(String.valueOf(finalresult));
                break;

            default: return;

        }

    }
    private double evaluateExpression(String res, String operatorPressed) {

        String[] tokens = res.split("\\+|-|\\*|\\/");
        double firstOperand = Double.parseDouble(tokens[0]);
        double secondOperand = Double.parseDouble(tokens[1]);

        switch(operatorPressed) {
            case "+":
                return firstOperand + secondOperand;
            case "-":
                return firstOperand - secondOperand;
            case "*":
                return firstOperand * secondOperand;
            case "/":
                return firstOperand / secondOperand;
            default:
                return 0;

        }

    }
}